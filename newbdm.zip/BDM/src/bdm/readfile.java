
package bdm;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class readfile {
    public static void main(String[] args) throws FileNotFoundException{
        
        File productname;
        productname = new File("C:\\Users\\SANDY\\Desktop\\prodresults.txt");
        
        Scanner scan = new Scanner(productname);
        while(scan.hasNext()){
        System.out.println(scan.nextLine());
        }
        
        
        
    }
   
}